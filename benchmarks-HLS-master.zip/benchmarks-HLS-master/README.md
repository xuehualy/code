# Benchmarks for high-level synthesis research
Benchmarks, testbenches, and transformed codes

# PLP: parametric loop pipelining

# LSP: loop splitting for pipelining

# PolyDLP (PLP+LSP): polyhedral-based dynamic loop pipelining

# Thesis: experiments for PhD thesis

