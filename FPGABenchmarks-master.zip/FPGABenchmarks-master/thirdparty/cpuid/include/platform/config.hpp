#if defined(_MSC_VER)
    #define PLATFORM_MSVC_X86
#elif defined(__GNUC__)
    #define PLATFORM_GCC_COMPATIBLE_X86
#endif
