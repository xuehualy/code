#pragma once

#include "cpuinfo.hpp"

static cpuid::cpuinfo cpuinfo;
