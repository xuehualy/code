#!/bin/bash

#./hurricane_gen 15690 1
#./hurricane_gen 21380 2
./hurricane_gen 42760 4
#./hurricane_gen 85520 8
#./hurricane_gen 171040 16
#./hurricane_gen 342080 32
#./hurricane_gen 684160 64
#./hurricane_gen 21893120 2048
