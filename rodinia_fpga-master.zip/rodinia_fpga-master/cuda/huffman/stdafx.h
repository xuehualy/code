#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <malloc.h>
#include <string.h>
#include <math.h>
#include <iostream>
#include <time.h>
#include "cutil.h"
