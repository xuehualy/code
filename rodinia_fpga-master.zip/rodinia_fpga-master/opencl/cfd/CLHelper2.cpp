#include "CLHelper2.h"

cl_context       context;
cl_command_queue cmd_queue;
cl_device_type   device_type;
cl_device_id   * device_list;
cl_int           num_devices;

