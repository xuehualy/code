#ifndef HOTSPOT_COMMON_H
#define HOTSPOT_COMMON_H

#define AMB_TEMP (80.0f)
#endif
